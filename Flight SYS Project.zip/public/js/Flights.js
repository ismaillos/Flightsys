$(document).ready(function() {
    loadFlights();

    $('#addFlight').click(function() {
        const flightData = {
            depart: $('#depart').val(),
            arrival: $('#arrival').val(),
            gare: $('#gare').val(),
            ville_depart: $('#ville_depart').val(),
            ville_destination: $('#ville_destination').val(),
            duree: $('#duree').val(),
            type: $('#type').val(),
        };
    
        $.ajax({
            url: 'http://localhost:5000/flights/',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(flightData),
            success: function(response) {
                loadFlights();
                $('#depart').val();
                $('#arrival').val();
                $('#gare').val();
                $('#ville_depart').val();
                $('#ville_destination').val();
                $('#duree').val();
                $('#type').val();
            }
        });
        flights.append(addFlight)
        return jsonify({'message': 'Flight added successfully'}), 201
    });
});


function loadFlights() {
    $.ajax({
        url: "http://localhost:5000/flights/",
        method: 'GET',
        success: function(flights) {
            $('#flightsList').empty();
            flights.forEach(function(flight) {
                $('#flightsList').append(
                    $('<li></li>').html(
                        '<div>${flight.airline} - From ${flight.departure} to ${flight.arrival}, Price: $${flight.ticketPrice}</div>' +
                        '<button class="edit" data-id="${flight._id}">Edit</button>'
                    )
                );
            });
        }
    });
}

$(document).on('click', '.edit', function() {
    const flightId = $(this).data('id');

    
    $.ajax({
        url: "ttp://localhost:5000/flights/+flightId", // Change this to your server's URL
        method: 'GET',
        success: function(flight) {
            // Fill the form inputs with the data from the flight object
            $('#depart').val(flight.departure);
            $('#arrival').val(flight.arrival);
            $('#gare').val(flight.gare);
            $('#ville_depart').val(flight.ville_depart);
            $('#ville_destination').val(flight.ville_destination);
            $('#duree').val(flight.duree);
            $('#type').val(flight.type);
        }
    });
});

function loadFlights() {
    $.ajax({
        url: "http://localhost:5000/flights/",
        method: 'GET',
        success: function(flights) {
            $('#flightsList').empty();
            flights.forEach(function(flight) {
                $('#flightsList').append(
                    $('<li></li>').html(
                        '<div>${flight.airline} - From ${flight.departure} to ${flight.arrival}, Price: $${flight.ticketPrice}</div>' +
                        '<button class="edit" data-id="${flight._id}">Edit</button>' +
                        '<button class="remove" data-id="${flight._id}">Remove</button>'
                    )
                );
            });
        }
    });
}

$(document).on('click', '.remove', function() {
    const flightId = $(this).data('id');

    $.ajax({
        url: "http://localhost:5000/flights/" + flightId, // Change this to your server's URL
        method: 'DELETE',
        success: function() {
            // Refresh the flights list
            loadFlights();
        }
    });
});

function loadFlights() {
    $.ajax({
        url:"http://localhost:5000/flights/",
        method: 'GET',
        success: function(flights) {
            $('#flightsList').empty();
            flights.forEach(function(flight) {
                $('#flightsList').append(<li>${flight.gare} - From ${flight.depart} to ${flight.arrival}, type: ${flight.type}</li>);
            });
        }
    });
}